package com.example.myapp

import android.animation.Animator
import android.animation.AnimatorInflater
import android.animation.AnimatorSet
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    lateinit var front_animat: AnimatorSet
    lateinit var back_animat: AnimatorSet
    var isFront = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val cardFront: TextView = findViewById(R.id.card_front)
        val cardBack: TextView = findViewById(R.id.card_back)
        val flipBtn: Button = findViewById(R.id.flip_btn)

        val scale = applicationContext.resources.displayMetrics.density

        cardFront.cameraDistance = 8000 * scale
        cardBack.cameraDistance = 8000 * scale

        front_animat = AnimatorInflater.loadAnimator(applicationContext, R.animator.front_anim) as AnimatorSet
        back_animat = AnimatorInflater.loadAnimator(applicationContext, R.animator.back_anim) as AnimatorSet

        flipBtn.setOnClickListener {
            if (!front_animat.isRunning && !back_animat.isRunning) {
                if (isFront) {
                    front_animat.setTarget(cardFront)
                    back_animat.setTarget(cardBack)
                    front_animat.start()
                    back_animat.start()
                    isFront = false
                } else {
                    front_animat.setTarget(cardBack)
                    back_animat.setTarget(cardFront)
                    back_animat.start()
                    front_animat.start()
                    isFront = true
                }
            }
        }
    }
}
